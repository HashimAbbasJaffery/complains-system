<template>
    <img src="https://gwadargymkhana.com.pk/complains/public/assets/images/black_logo.png" width="130">
</template>
<script setup>

</script>
